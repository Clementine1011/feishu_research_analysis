# 飞书开放平台事件回调服务

本项目是一个基于 Node.js/Express 的轻量级 Web 服务，用于接收和处理来自飞书开放平台的事件回调。它为“标注流程追踪工具”提供了核心的后端逻辑，能够响应多维表格记录变更、交互式卡片点击和飞书任务状态更新，是连接飞书 Bitable、IM 与 Tasks 的枢纽。

服务设计上遵循“配置驱动”，通过 `trigger_config.json` 文件将业务逻辑（如哪个表的什么状态变更，应推送哪张卡片）与代码实现解耦，便于 RD 或 Coze 同学快速调整和扩展。

## 功能特性

- **事件处理骨架**：内置 Express 服务器，提供对飞书事件回调的完整处理流程，包括 URL 校验、Verification Token 验证和事件解密（预留逻辑）。
- **模块化处理器**：将不同类型的事件（多维表格、卡片、任务）分发到独立的 handler 文件中处理，结构清晰。
- **配置驱动**：通过 `trigger_config.json` 文件映射事件触发条件与卡片模板，使业务规则调整无需修改代码。
- **环境变量支持**：所有敏感信息和环境相关配置均通过 `.env` 文件加载，与代码完全分离。
- **容器化部署**：提供 `Dockerfile`，支持快速、一致地部署到生产环境。

## 部署与运行

你可以通过 Docker 快速部署本服务。

### 1. 准备配置文件

在项目根目录（`bot_webhook/`）下，复制 `.env.example` 文件并重命名为 `.env`：

```bash
cp .env.example .env
```

然后，编辑 `.env` 文件，填入你的飞书机器人凭据和环境配置。详细说明见「环境变量配置」章节。

### 2. 构建并运行 Docker 容器

在项目根目录下执行以下命令：

```bash
# 构建 Docker 镜像，可以自定义镜像名称和标签
docker build -t feishu-callback-server:latest .

# 以后台模式运行容器，并将容器的 PORT 端口映射到宿主机的 8080 端口
# 你可以根据需要修改宿主机端口
docker run -d -p 8080:3000 --name feishu-bot-server --env-file ./.env feishu-callback-server:latest
```

> **注意：** `-p 8080:3000` 表示将宿主机的 8080 端口映射到容器内服务的 3000 端口（或你在 `.env` 中设置的 `PORT`）。请确保你的服务器防火墙和安全组已放开此宿主机端口。

部署成功后，你的回调服务将在 `http://<your.domain.com>:8080` 上运行。

## 环境变量配置

所有配置项均在 `.env` 文件中设置。

| 变量名               | 是否必须 | 说明                                                                                                                                                                                             |
| -------------------- | -------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `APP_ID`             | **是**   | 你的飞书机器人的 App ID。已在 `.env.example` 中预填。                                                                                                                                              |
| `APP_SECRET`         | **是**   | 你的飞书机器人的 App Secret。用于获取 `tenant_access_token`。**请务必填写。**                                                                                                                        |
| `VERIFICATION_TOKEN` | **是**   | 事件订阅的 Verification Token。在飞书开放平台“事件订阅”页面获取，用于校验回调请求的合法性。**建议生产环境必须配置。**                                                                                 |
| `ENCRYPT_KEY`        | 可选     | 事件订阅的 Encrypt Key。如果在开放平台开启了加密，则必须配置此项，服务将自动进行解密。                                                                                                                 |
| `CALLBACK_PATH`      | 可选     | 事件回调的路径。默认为 `feishu/callback`。最终的回调 URL 将是 `https://your.domain.com/${CALLBACK_PATH}`。你可以自定义，但要与开放平台设置保持一致。                                                 |
| `PORT`               | 可选     | 服务监听的端口号。默认为 `3000`。`Dockerfile` 会将此端口暴露出来。                                                                                                                                |

## 飞书开放平台配置

### 1. 事件订阅

你需要为你的机器人（`APP_ID: cli_a960594f28391bda`）在飞书开放平台的“事件订阅”页面开启并订阅以下事件。`open-platform-config.json` 文件中已为你声明了所需的事件类型与描述。

- **多维表格**
  - `bitable.app.table.record.created_v1`
  - `bitable.app.table.record.updated_v1`
- **消息与群组**
  - `card.action.trigger`
- **任务**
  - `task.task_status_changed_v1`

### 2. 请求地址配置（回调 URL）

在“事件订阅”页面，你需要填写“请求地址 URL”。这个 URL 必须是公网可访问的 HTTPS 地址，指向你部署的本服务。

其格式为 `https://<your.domain.com>/<CALLBACK_PATH>`。

**示例：**
- 如果你的服务部署在 `example.com`，使用默认的 `CALLBACK_PATH`，则回调 URL 为：
  `https://example.com/feishu/callback`
- 如果你将 `.env` 中的 `CALLBACK_PATH` 修改为 `my-bot/handler`，则回调 URL 应为：
  `https://example.com/my-bot/handler`

> **提示：** 首次填写并保存回调 URL 时，飞书平台会向该地址发送一个 `url_verification` 类型的 POST 请求，本服务已内置处理逻辑，会自动响应 challenge 请求以完成验证。

### 3. 权限范围

请确保你的机器人已在“权限管理”页面开通以下权限，以便服务能正常调用 API：

- **多维表格**
  - `bitable:app:readonly`
  - `bitable:app`
  - `bitable:field:readonly`
  - `bitable:record:readonly`
  - `bitable:record`
  - `bitable:table:readonly`
  - `bitable:table`
  - `bitable:view:readonly`
- **消息**
  - `im:message`
  - `im:message.group_at_msg:readonly`
  - `im:message.p2p_msg:readonly`
  - `im:message:send_as_bot`
- **任务**
  - `task:task:readonly`
  - `task:task`
- **通讯录**
  - `contact:user.id:readonly` (用于通过用户邮箱或手机号获取 open_id)

## 与多维表格的关联

本服务通过根目录的 `trigger_config.json` 文件与你已创建的“标注流程追踪 Base”进行关联。

- **文件位置**：`bot_webhook/trigger_config.json`
- **作用**：定义了什么条件下（`condition`）应触发哪张卡片（`card_id`），以及卡片上的按钮应链接到哪个多维表格视图（`target_view_url`）。
- **关联说明**：
  - `table_id` 字段直接关联到“标注流程追踪 Base”中的四张主表。
  - `condition` 字段描述了触发业务逻辑的条件，例如当“需求主表”的“状态”字段变为“待上传”时。
  - `card_id` 是预先通过 `feishu-im-send` 的 `create_card` 创建的卡片实体 ID，服务侧拿到这个 ID 后即可推送对应的卡片。
  - `target_view_url` 则直接链接到你在多维表格中配置好的视图，例如“进行中”、“待校验”等。

当 RD 或 Coze 同学进行二次开发时，只需关注 `src/handlers/` 目录下的三个文件，并基于 `trigger_config.json` 的配置，在占位逻辑中补充调用飞书开放平台 API 的代码（如发送卡片、回写字段、创建任务等），即可完成整个闭环。
