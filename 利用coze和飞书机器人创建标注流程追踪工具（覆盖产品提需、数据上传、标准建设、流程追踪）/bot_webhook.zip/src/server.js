'use strict';

const express = require('express');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const dotenv = require('dotenv');

dotenv.config();

const bitableHandler = require('./handlers/bitable');
const cardHandler = require('./handlers/card');
const tasksHandler = require('./handlers/tasks');

const app = express();

// Feishu 事件回调均为 JSON，这里统一按 JSON 解析。
app.use(bodyParser.json({ type: '*/*' }));

const PORT = process.env.PORT || 3000;
const CALLBACK_PATH = (process.env.CALLBACK_PATH || 'feishu/callback').replace(/^\//, '');
const ENCRYPT_KEY = process.env.ENCRYPT_KEY;
const VERIFICATION_TOKEN = process.env.VERIFICATION_TOKEN;

/**
 * 校验飞书回调中的 Verification Token。
 * 如果未配置 VERIFICATION_TOKEN，则跳过校验（方便本地开发），建议生产环境必须配置。
 */
function verifyToken(body) {
  if (!VERIFICATION_TOKEN) {
    return true;
  }
  const tokenFromBody = (body && (body.token || (body.header && body.header.token))) || '';
  return tokenFromBody === VERIFICATION_TOKEN;
}

/**
 * 如配置了 ENCRYPT_KEY，则在此处对加密事件进行解密。
 * 当前仅预留逻辑占位，具体实现请参考飞书开放平台「事件订阅加密」文档。
 */
function maybeDecrypt(body) {
  if (!ENCRYPT_KEY || !body || !body.encrypt) {
    return body;
  }

  // TODO: 使用 ENCRYPT_KEY 对 body.encrypt 进行 AES 解密，并将解密出的明文 JSON 作为后续事件体。
  // 示例伪代码（请根据飞书官方文档补全）：
  // const encryptedBuffer = Buffer.from(body.encrypt, 'base64');
  // const iv = encryptedBuffer.slice(0, 16);
  // const data = encryptedBuffer.slice(16);
  // const key = crypto.createHash('sha256').update(ENCRYPT_KEY).digest();
  // const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
  // const decrypted = Buffer.concat([decipher.update(data), decipher.final()]);
  // return JSON.parse(decrypted.toString('utf8'));

  return body; // 当前直接返回原始 body，只作为占位。
}

/**
 * 将飞书回调事件按 event_type 分发到不同业务 handler。
 */
async function dispatchEvent(envelope) {
  const header = envelope.header || {};
  const eventType = header.event_type || (envelope.event && envelope.event.type) || envelope.type;

  switch (eventType) {
    case 'bitable.app.table.record.created':
    case 'bitable.app.table.record.updated':
      await bitableHandler.handleBitableEvent(envelope);
      break;
    case 'card.action.trigger':
      await cardHandler.handleCardEvent(envelope);
      break;
    case 'task.task_status_changed_v1':
      await tasksHandler.handleTaskEvent(envelope);
      break;
    default:
      // 其他未关心的事件类型直接忽略。
      break;
  }
}

app.post(`/${CALLBACK_PATH}`, async (req, res) => {
  let body = req.body || {};

  // 如开启加密，优先尝试解密。
  body = maybeDecrypt(body);

  // URL 校验（url_verification）流程。
  if (body.type === 'url_verification') {
    if (!verifyToken(body)) {
      return res.status(401).json({ code: 1, msg: 'invalid verification token' });
    }
    return res.json({ challenge: body.challenge });
  }

  // 校验 Verification Token。
  if (!verifyToken(body)) {
    return res.status(401).json({ code: 1, msg: 'invalid verification token' });
  }

  // 先快速返回，避免阻塞飞书回调超时；具体业务逻辑在后台异步处理。
  res.json({ code: 0, msg: 'ok' });

  // 异步分发处理，不阻塞主流程。
  Promise.resolve(dispatchEvent(body)).catch((err) => {
    // 生产环境建议接入专门的日志系统，这里仅简要输出。
    console.error('Error handling Feishu event:', err && err.message ? err.message : err);
  });
});

// 简单健康检查端点，便于探活。
app.get('/healthz', (req, res) => {
  res.send('ok');
});

app.listen(PORT, () => {
  // 控制台日志不包含任何敏感信息，仅用于运维排查。
  console.log(`Feishu callback server listening on port ${PORT}, path /${CALLBACK_PATH}`);
});
