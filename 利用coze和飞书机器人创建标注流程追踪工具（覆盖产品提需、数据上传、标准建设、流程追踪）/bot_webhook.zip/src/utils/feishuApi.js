'use strict';

const axios = require('axios');
const dotenv = require('dotenv');

dotenv.config();

const { APP_ID, APP_SECRET } = process.env;

// 飞书开放平台基础域名（如需使用其他区域/内网出口，请在部署时调整）。
const BASE_URL = 'https://open.feishu.cn/open-apis';

const client = axios.create({
  baseURL: BASE_URL,
  timeout: 8000
});

let cachedToken = null;
let cachedTokenExpireAt = 0;

/**
 * 获取 tenant_access_token，占位实现。
 * 在正式环境建议增加：
 * - 错误重试与降级；
 * - 多实例共享缓存（如 Redis）；
 * - 过期前刷新等逻辑。
 */
async function getTenantAccessToken() {
  const now = Date.now();
  if (cachedToken && cachedTokenExpireAt > now + 60 * 1000) {
    return cachedToken;
  }

  if (!APP_ID || !APP_SECRET) {
    throw new Error('APP_ID / APP_SECRET 未配置，无法获取 tenant_access_token');
  }

  const url = `${BASE_URL}/auth/v3/tenant_access_token/internal`;
  const resp = await axios.post(url, {
    app_id: APP_ID,
    app_secret: APP_SECRET
  });

  if (!resp.data || resp.data.code !== 0) {
    throw new Error(`获取 tenant_access_token 失败: ${JSON.stringify(resp.data || {})}`);
  }

  cachedToken = resp.data.tenant_access_token;
  // 过期时间（秒）减去一点缓冲，避免边界问题。
  const expire = resp.data.expire || 7000;
  cachedTokenExpireAt = now + expire * 1000;
  return cachedToken;
}

/**
 * 通用请求封装：自动附带 Authorization 头。
 *
 * 使用示例：
 * await feishuRequest({
 *   method: 'POST',
 *   url: '/bitable/v1/apps/{app_token}/tables/{table_id}/records',
 *   data: { /* ... *\/ }
 * });
 */
async function feishuRequest(options) {
  const {
    method = 'GET',
    url,
    params,
    data,
    headers = {},
    ...rest
  } = options;

  const token = await getTenantAccessToken();

  const resp = await client.request({
    method,
    url,
    params,
    data,
    headers: {
      Authorization: `Bearer ${token}`,
      ...headers
    },
    ...rest
  });

  return resp.data;
}

module.exports = {
  feishuRequest
};
