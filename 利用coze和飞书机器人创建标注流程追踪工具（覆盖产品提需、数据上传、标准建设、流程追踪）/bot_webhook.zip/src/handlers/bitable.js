'use strict';

const fs = require('fs');
const path = require('path');
// 预留：如需在此处直接调用开放平台，可引入 feishuApi。
// const { feishuRequest } = require('../utils/feishuApi');

let triggerConfigCache = null;

function loadTriggerConfig() {
  if (!triggerConfigCache) {
    const configPath = path.join(__dirname, '..', 'trigger_config.json');
    if (fs.existsSync(configPath)) {
      const raw = fs.readFileSync(configPath, 'utf8');
      triggerConfigCache = JSON.parse(raw);
    } else {
      triggerConfigCache = [];
    }
  }
  return triggerConfigCache;
}

/**
 * 根据 trigger_config.json 的 condition 字段占位匹配逻辑。
 * 这里只给出占位结构，具体判断规则可由 RD/Coze 同学按实际需要补充。
 */
function matchRuleCondition(condition, event) {
  if (!condition) return true;

  // 示例：按字段名取出当前值，结合 condition.type 进行判断。
  const fieldName = condition.field_name;
  const recordFields = (event.record && event.record.fields) || event.fields || {};
  const currentValue = recordFields[fieldName];

  switch (condition.type) {
    case 'value_change':
      // 实际上需要同时拿到变更前后的值，这里仅保留占位说明。
      // 可以通过 event.old 和 event.new 等字段由上游传入。
      return true;
    case 'record_update':
      if (Array.isArray(condition.in)) {
        return condition.in.includes(currentValue);
      }
      if (Object.prototype.hasOwnProperty.call(condition, 'equals')) {
        return currentValue === condition.equals;
      }
      return true;
    default:
      return true;
  }
}

/**
 * 处理多维表格（Bitable）记录新增/更新事件。
 *
 * 这里不直接发送任何消息，仅：
 * - 解析事件结构；
 * - 基于 trigger_config.json 找到对应的触发配置；
 * - 留出卡片推送与字段回写的逻辑占位，便于 RD/Coze 落实。
 */
async function handleBitableEvent(envelope) {
  const triggerConfig = loadTriggerConfig();
  const event = envelope.event || {};

  const tableId = event.table_id;
  const recordId = event.record_id;

  if (!tableId || !recordId) {
    return;
  }

  const rulesForTable = triggerConfig.filter((rule) => rule.table_id === tableId);
  if (!rulesForTable.length) {
    return;
  }

  const matchedRules = rulesForTable.filter((rule) => matchRuleCondition(rule.condition, event));
  if (!matchedRules.length) {
    return;
  }

  // 占位逻辑：此处仅说明后续应做的事情，不实际调用任何发送/写入接口。
  matchedRules.forEach((rule) => {
    // 示例：
    // 1）根据 rule.card_file / rule.card_id 决定要使用哪一种卡片模板；
    // 2）准备卡片所需的上下文字段（例如记录中的需求编号、标题、SLA 等）；
    // 3）将卡片推送到对应群组或个人（由上层服务基于 card_id 和 open_id/群ID 实现）；
    // 4）如有需要，在卡片交互完成后，通过开放平台接口回写对应的字段（状态、完成标记、关联任务等）。

    // 这里不做任何实际调用，确保不会产生测试消息或真实数据变更。
  });
}

module.exports = {
  handleBitableEvent
};
