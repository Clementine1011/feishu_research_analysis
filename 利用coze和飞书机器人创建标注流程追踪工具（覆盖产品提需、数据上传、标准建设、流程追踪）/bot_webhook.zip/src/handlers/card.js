'use strict';

const fs = require('fs');
const path = require('path');
// 预留：如需直接在卡片回调中回写多维表或任务，可引入 feishuApi。
// const { feishuRequest } = require('../utils/feishuApi');

let triggerConfigCache = null;

function loadTriggerConfig() {
  if (!triggerConfigCache) {
    const configPath = path.join(__dirname, '..', 'trigger_config.json');
    if (fs.existsSync(configPath)) {
      const raw = fs.readFileSync(configPath, 'utf8');
      triggerConfigCache = JSON.parse(raw);
    } else {
      triggerConfigCache = [];
    }
  }
  return triggerConfigCache;
}

/**
 * 处理交互式卡片回调事件。
 *
 * 通常 event 结构示例（简化）：
 * {
 *   "header": { "event_type": "card.action.trigger", ... },
 *   "event": {
 *     "action": {
 *       "tag": "approve",          // 按钮标识
 *       "value": { ... },           // 自定义的业务参数，如 table_id / record_id / next_status
 *       "form_value": { ... }      // 用户在卡片中填写的表单值
 *     },
 *     "card": {
 *       "card_id": "7633...",     // 与 trigger_config.json 中的 card_id 对应
 *       "open_message_id": "om_..."
 *     }
 *   }
 * }
 */
async function handleCardEvent(envelope) {
  const cfg = loadTriggerConfig();
  const event = envelope.event || {};
  const action = event.action || {};

  const card = event.card || {};
  const cardId = card.card_id;
  const actionTag = action.tag; // 如 "approve" / "reject" / "complete" 等
  const actionValue = action.value || {};
  const formValue = action.form_value || {};

  if (!cardId) {
    return;
  }

  const rule = cfg.find((item) => item.card_id === cardId);
  if (!rule) {
    return;
  }

  // 占位逻辑：根据 cardId / actionTag / actionValue / formValue 决定如何回写字段。
  // 建议在 card JSON 模板中通过 action.value 传入 table_id、record_id、next_status 等业务字段，
  // 然后在此处：
  // 1）解析出多维表的 app_token / table_id / record_id；
  // 2）根据 actionTag 确认本次操作类型（例如 评审通过/驳回、完成上传、标记完成 等）；
  // 3）构造对应的字段更新数据；
  // 4）通过 feishuApi 封装的开放平台接口完成回写。

  // 示例伪代码（仅注释，不实际调用）：
  // if (actionTag === 'approve') {
  //   await feishuRequest({
  //     method: 'PATCH',
  //     url: `/bitable/v1/apps/${appToken}/tables/${rule.table_id}/records/${recordId}`,
  //     data: { fields: { '评审结论': '通过' } }
  //   });
  // }
}

module.exports = {
  handleCardEvent
};
