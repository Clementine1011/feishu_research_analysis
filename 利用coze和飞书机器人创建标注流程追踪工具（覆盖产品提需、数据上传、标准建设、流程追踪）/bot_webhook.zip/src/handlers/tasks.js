'use strict';

// 预留：如需在任务状态变更时同步更新多维表，可引入 feishuApi。
// const { feishuRequest } = require('../utils/feishuApi');

/**
 * 处理飞书任务状态变更事件。
 *
 * 典型场景：
 * - 当任务状态从「未完成」变更为「已完成」时，将过程追踪/任务表中的「完成标记」置为 true；
 * - 根据任务中携带的关联信息（如 关联需求 ID / 任务表记录 ID），更新需求主表的状态或推进到下一阶段；
 * - 结合 trigger_config.json，视需要再次触发下一阶段的卡片推送。
 */
async function handleTaskEvent(envelope) {
  const event = envelope.event || {};
  const task = event.task || {};

  const taskId = task.id || task.task_id;
  const status = task.status;

  if (!taskId) {
    return;
  }

  // 占位说明：
  // 建议在创建飞书任务时，将 Bitable 记录的关键标识（如 任务表记录 ID、需求主表记录 ID）
  // 通过自定义字段或扩展属性写入任务中，以便在此处反向定位对应的多维表记录。
  //
  // 示例伪代码（仅注释，不实际调用）：
  // if (status === 'done') {
  //   // 1）根据任务中的自定义字段找到对应的 Bitable 记录；
  //   // 2）更新过程追踪/任务表中的「完成标记」为 true；
  //   // 3）视需求更新需求主表的「状态」字段，如从 "执行中" → "已完成"；
  //   // 4）如需触发下一阶段卡片，可复用 trigger_config.json 的配置，在上层服务中再次推送卡片。
  // }
}

module.exports = {
  handleTaskEvent
};
